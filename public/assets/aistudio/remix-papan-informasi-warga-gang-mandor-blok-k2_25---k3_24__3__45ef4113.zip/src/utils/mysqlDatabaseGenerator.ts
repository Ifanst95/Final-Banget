import type {
  Announcement,
  BaksosAgenda,
  CashTransaction,
  CommitteeContact,
  ResidentHouse,
  SiteConfig,
} from '../types.ts';

export interface MySQLDatabasePayload {
  version?: number;
  updatedAt?: string;
  updatedBy?: string;
  siteConfig: SiteConfig;
  residents: ResidentHouse[];
  transactions: CashTransaction[];
  baksosAgendas: BaksosAgenda[];
  committees: CommitteeContact[];
  announcements: Announcement[];
}

export interface MySQLTableSummary {
  tableName: string;
  description: string;
  rowCount: number;
  primaryKey: string;
  columns: string[];
}

function escapeSql(val: string | number | boolean | null | undefined): string {
  if (val === null || val === undefined) return 'NULL';
  if (typeof val === 'boolean') return val ? '1' : '0';
  if (typeof val === 'number') return Number.isFinite(val) ? String(val) : '0';
  const escaped = String(val)
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'")
    .replace(/\r/g, '\\r')
    .replace(/\n/g, '\\n');
  return `'${escaped}'`;
}

/**
 * Menghasilkan ringkasan tabel relasional MySQL untuk seluruh inputan di website
 */
export function getMySQLTablesSummary(payload: MySQLDatabasePayload): MySQLTableSummary[] {
  const familyMembersCount = (payload.residents || []).reduce(
    (sum, r) => sum + (r.members?.length || 0),
    0
  );
  const baksosAttendanceCount = (payload.baksosAgendas || []).reduce(
    (sum, a) => sum + Object.keys(a.attendance || {}).length,
    0
  );

  return [
    {
      tableName: 'site_config',
      description: 'Konfigurasi Website, Judul Seksi, Nominal Iuran & Periode Bulan',
      rowCount: 1,
      primaryKey: 'config_id',
      columns: [
        'config_id',
        'brand_name',
        'title',
        'subtitle',
        'dues_amount_per_month',
        'dues_current_month',
        'updated_at',
      ],
    },
    {
      tableName: 'residents',
      description: 'Data Induk Rumah / Kepala Keluarga (KK), Status Iuran Kas, Rukem & WiFi',
      rowCount: payload.residents?.length || 0,
      primaryKey: 'id',
      columns: [
        'id',
        'block_number',
        'head_name',
        'phone',
        'ownership',
        'occupancy',
        'rukem_status',
        'wifi_status',
        'wifi_provider',
        'dues_status',
        'custom_dues_amount',
        'dues_paid_amount',
        'dues_paid_months',
        'dues_prepaid_balance',
        'dues_paid_date',
        'dues_month_note',
        'previous_arrears',
        'previous_arrears_note',
        'updated_at',
      ],
    },
    {
      tableName: 'family_members',
      description: 'Data Seluruh Anggota Keluarga per Rumah (Nama, Peran, Tgl Lahir, Gender, Agama, Pekerjaan)',
      rowCount: familyMembersCount,
      primaryKey: 'id',
      columns: [
        'id',
        'resident_id',
        'block_number',
        'full_name',
        'relation_role',
        'birth_place',
        'birth_date',
        'gender',
        'religion',
        'occupation',
      ],
    },
    {
      tableName: 'cash_transactions',
      description: 'Buku Mutasi Keuangan Keluar & Masuk (Kas Utama, Cashback WiFi, Cashback Sampah)',
      rowCount: payload.transactions?.length || 0,
      primaryKey: 'id',
      columns: [
        'id',
        'tx_date',
        'tx_type',
        'pool_name',
        'category',
        'description',
        'amount',
      ],
    },
    {
      tableName: 'baksos_agendas',
      description: 'Jadwal & Kegiatan Kerja Bakti / Bakti Sosial Gang',
      rowCount: payload.baksosAgendas?.length || 0,
      primaryKey: 'id',
      columns: ['id', 'agenda_date', 'title', 'description', 'fine_amount'],
    },
    {
      tableName: 'baksos_attendance',
      description: 'Daftar Presensi Kehadiran & Status Lunas Denda Baksos per Rumah',
      rowCount: baksosAttendanceCount,
      primaryKey: 'agenda_id, resident_id',
      columns: ['agenda_id', 'resident_id', 'attendance_status', 'fine_paid'],
    },
    {
      tableName: 'committees',
      description: 'Daftar Kontak Pelayanan Publik & Pengurus Gang',
      rowCount: payload.committees?.length || 0,
      primaryKey: 'id',
      columns: ['id', 'full_name', 'role_title', 'phone_number'],
    },
    {
      tableName: 'announcements',
      description: 'Papan Pengumuman & Agenda Informasi Warga',
      rowCount: payload.announcements?.length || 0,
      primaryKey: 'id',
      columns: ['id', 'title', 'publish_date', 'priority', 'content'],
    },
  ];
}

/**
 * Menghasilkan script MySQL (.sql) lengkap (CREATE DATABASE, CREATE TABLE, INSERT INTO)
 * untuk seluruh inputan di website
 */
export function generateMySQLDump(payload: MySQLDatabasePayload): string {
  const nowStr = payload.updatedAt || new Date().toISOString();
  const cfg = payload.siteConfig || ({} as SiteConfig);
  const lines: string[] = [];

  lines.push('-- ============================================================================');
  lines.push('-- MYSQL DATABASE DUMP: PORTAL INFORMASI WARGA GANG MANDOR BLOK K2/25 - K3/24');
  lines.push(`-- Generated At : ${nowStr}`);
  lines.push(`-- Updated By   : ${payload.updatedBy || 'Sistem Database MySQL Gang Mandor'}`);
  lines.push('-- Compatible   : MySQL 5.7+ / MySQL 8.0+ / MariaDB 10.4+ / phpMyAdmin');
  lines.push('-- ============================================================================');
  lines.push('');
  lines.push('SET NAMES utf8mb4;');
  lines.push('SET FOREIGN_KEY_CHECKS = 0;');
  lines.push('SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";');
  lines.push('SET time_zone = "+07:00";');
  lines.push('');
  lines.push('CREATE DATABASE IF NOT EXISTS `db_warga_gang_mandor` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;');
  lines.push('USE `db_warga_gang_mandor`;');
  lines.push('');

  // 1. Table: site_config
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('-- 1. Struktur Tabel `site_config` (Konfigurasi Website & Parameter Kas)');
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('DROP TABLE IF EXISTS `site_config`;');
  lines.push('CREATE TABLE `site_config` (');
  lines.push('  `config_id` INT NOT NULL PRIMARY KEY,');
  lines.push('  `brand_name` VARCHAR(255) NOT NULL,');
  lines.push('  `title` VARCHAR(255) NOT NULL,');
  lines.push('  `subtitle` VARCHAR(255) DEFAULT NULL,');
  lines.push('  `description` TEXT DEFAULT NULL,');
  lines.push('  `dues_amount_per_month` BIGINT NOT NULL DEFAULT 50000,');
  lines.push('  `dues_current_month` VARCHAR(100) NOT NULL DEFAULT \'Oktober 2026\',');
  lines.push('  `cash_description` TEXT DEFAULT NULL,');
  lines.push('  `wifi_cashback_description` TEXT DEFAULT NULL,');
  lines.push('  `trash_cashback_description` TEXT DEFAULT NULL,');
  lines.push('  `updated_at` DATETIME NOT NULL');
  lines.push(') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
  lines.push('');
  lines.push(
    `INSERT INTO \`site_config\` (\`config_id\`, \`brand_name\`, \`title\`, \`subtitle\`, \`description\`, \`dues_amount_per_month\`, \`dues_current_month\`, \`cash_description\`, \`wifi_cashback_description\`, \`trash_cashback_description\`, \`updated_at\`) VALUES (1, ${escapeSql(
      cfg.brandName || 'Warga Gang Mandor K2/25–K3/24'
    )}, ${escapeSql(cfg.title || 'Papan Informasi Warga Gang Mandor')}, ${escapeSql(
      cfg.subtitle || ''
    )}, ${escapeSql(cfg.description || '')}, ${Number(
      cfg.duesAmountPerMonth || 50000
    )}, ${escapeSql(cfg.duesCurrentMonth || 'Oktober 2026')}, ${escapeSql(
      cfg.cashDescription || ''
    )}, ${escapeSql(cfg.wifiCashbackDescription || '')}, ${escapeSql(
      cfg.trashCashbackDescription || ''
    )}, NOW());`
  );
  lines.push('');

  // 2. Table: residents
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('-- 2. Struktur Tabel `residents` (Data Rumah KK, Iuran Kas, Rukem, WiFi, Tunggakan)');
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('DROP TABLE IF EXISTS `residents`;');
  lines.push('CREATE TABLE `residents` (');
  lines.push('  `id` VARCHAR(64) NOT NULL PRIMARY KEY,');
  lines.push('  `block_number` VARCHAR(32) NOT NULL UNIQUE,');
  lines.push('  `head_name` VARCHAR(150) NOT NULL,');
  lines.push('  `phone` VARCHAR(40) DEFAULT NULL,');
  lines.push('  `ownership` VARCHAR(50) NOT NULL DEFAULT \'Milik Sendiri\',');
  lines.push('  `occupancy` VARCHAR(50) NOT NULL DEFAULT \'Ditempati\',');
  lines.push('  `rukem_status` VARCHAR(50) NOT NULL DEFAULT \'Ikut Rukem\',');
  lines.push('  `wifi_status` VARCHAR(50) NOT NULL DEFAULT \'Tidak Pasang\',');
  lines.push('  `wifi_provider` VARCHAR(100) DEFAULT \'-\',');
  lines.push('  `dues_status` VARCHAR(32) NOT NULL DEFAULT \'Belum Bayar\',');
  lines.push('  `custom_dues_amount` BIGINT DEFAULT NULL,');
  lines.push('  `dues_paid_amount` BIGINT NOT NULL DEFAULT 0,');
  lines.push('  `dues_paid_months` INT NOT NULL DEFAULT 1,');
  lines.push('  `dues_prepaid_balance` BIGINT NOT NULL DEFAULT 0,');
  lines.push('  `dues_paid_date` VARCHAR(20) DEFAULT NULL,');
  lines.push('  `dues_month_note` VARCHAR(100) DEFAULT NULL,');
  lines.push('  `previous_arrears` BIGINT NOT NULL DEFAULT 0,');
  lines.push('  `previous_arrears_note` VARCHAR(255) DEFAULT NULL,');
  lines.push('  `updated_at` VARCHAR(40) DEFAULT NULL');
  lines.push(') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
  lines.push('');

  if (payload.residents && payload.residents.length > 0) {
    lines.push(
      'INSERT INTO `residents` (`id`, `block_number`, `head_name`, `phone`, `ownership`, `occupancy`, `rukem_status`, `wifi_status`, `wifi_provider`, `dues_status`, `custom_dues_amount`, `dues_paid_amount`, `dues_paid_months`, `dues_prepaid_balance`, `dues_paid_date`, `dues_month_note`, `previous_arrears`, `previous_arrears_note`, `updated_at`) VALUES'
    );
    const residentValues = payload.residents.map(
      (r) =>
        `  (${escapeSql(r.id)}, ${escapeSql(r.blockNumber)}, ${escapeSql(
          r.headName
        )}, ${escapeSql(r.phone || '')}, ${escapeSql(r.ownership)}, ${escapeSql(
          r.occupancy
        )}, ${escapeSql(r.rukem)}, ${escapeSql(r.wifiStatus)}, ${escapeSql(
          r.wifiProvider || '-'
        )}, ${escapeSql(r.duesStatus)}, ${
          r.customDuesAmount !== undefined ? Number(r.customDuesAmount) : 'NULL'
        }, ${Number(r.duesPaidAmount || 0)}, ${Number(r.duesPaidMonths || 1)}, ${Number(
          r.duesPrepaidBalance || 0
        )}, ${escapeSql(r.duesPaidDate || '')}, ${escapeSql(
          r.duesMonthNote || ''
        )}, ${Number(r.previousArrears || 0)}, ${escapeSql(
          r.previousArrearsNote || ''
        )}, ${escapeSql(r.updatedAt || nowStr)})`
    );
    lines.push(residentValues.join(',\n') + ';');
  }
  lines.push('');

  // 3. Table: family_members
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('-- 3. Struktur Tabel `family_members` (Buku Induk Anggota Keluarga per Rumah)');
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('DROP TABLE IF EXISTS `family_members`;');
  lines.push('CREATE TABLE `family_members` (');
  lines.push('  `id` VARCHAR(64) NOT NULL PRIMARY KEY,');
  lines.push('  `resident_id` VARCHAR(64) NOT NULL,');
  lines.push('  `block_number` VARCHAR(32) NOT NULL,');
  lines.push('  `full_name` VARCHAR(150) NOT NULL,');
  lines.push('  `relation_role` VARCHAR(50) NOT NULL,');
  lines.push('  `birth_place` VARCHAR(100) DEFAULT NULL,');
  lines.push('  `birth_date` DATE DEFAULT NULL,');
  lines.push('  `gender` VARCHAR(20) NOT NULL,');
  lines.push('  `religion` VARCHAR(40) NOT NULL,');
  lines.push('  `occupation` VARCHAR(120) DEFAULT NULL,');
  lines.push('  CONSTRAINT `fk_member_resident` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE');
  lines.push(') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
  lines.push('');

  const allMemberRows: string[] = [];
  (payload.residents || []).forEach((r) => {
    (r.members || []).forEach((m) => {
      allMemberRows.push(
        `  (${escapeSql(m.id)}, ${escapeSql(r.id)}, ${escapeSql(r.blockNumber)}, ${escapeSql(
          m.name
        )}, ${escapeSql(m.relation)}, ${escapeSql(m.birthPlace || '')}, ${
          m.birthDate ? escapeSql(m.birthDate) : 'NULL'
        }, ${escapeSql(m.gender)}, ${escapeSql(m.religion)}, ${escapeSql(
          m.occupation || ''
        )})`
      );
    });
  });

  if (allMemberRows.length > 0) {
    lines.push(
      'INSERT INTO `family_members` (`id`, `resident_id`, `block_number`, `full_name`, `relation_role`, `birth_place`, `birth_date`, `gender`, `religion`, `occupation`) VALUES'
    );
    lines.push(allMemberRows.join(',\n') + ';');
  }
  lines.push('');

  // 4. Table: cash_transactions
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('-- 4. Struktur Tabel `cash_transactions` (Mutasi Keuangan Keluar & Masuk Kas)');
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('DROP TABLE IF EXISTS `cash_transactions`;');
  lines.push('CREATE TABLE `cash_transactions` (');
  lines.push('  `id` VARCHAR(64) NOT NULL PRIMARY KEY,');
  lines.push('  `tx_date` DATE NOT NULL,');
  lines.push('  `tx_type` ENUM(\'masuk\', \'keluar\') NOT NULL,');
  lines.push('  `pool_name` VARCHAR(50) NOT NULL DEFAULT \'Kas Utama\',');
  lines.push('  `category` VARCHAR(80) NOT NULL,');
  lines.push('  `description` TEXT NOT NULL,');
  lines.push('  `amount` BIGINT NOT NULL DEFAULT 0');
  lines.push(') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
  lines.push('');

  if (payload.transactions && payload.transactions.length > 0) {
    lines.push(
      'INSERT INTO `cash_transactions` (`id`, `tx_date`, `tx_type`, `pool_name`, `category`, `description`, `amount`) VALUES'
    );
    const txRows = payload.transactions.map(
      (tx) =>
        `  (${escapeSql(tx.id)}, ${escapeSql(tx.date)}, ${escapeSql(tx.type)}, ${escapeSql(
          tx.pool
        )}, ${escapeSql(tx.category)}, ${escapeSql(tx.description)}, ${Number(tx.amount || 0)})`
    );
    lines.push(txRows.join(',\n') + ';');
  }
  lines.push('');

  // 5. Table: baksos_agendas
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('-- 5. Struktur Tabel `baksos_agendas` (Jadwal Kegiatan Bakti Sosial)');
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('DROP TABLE IF EXISTS `baksos_agendas`;');
  lines.push('CREATE TABLE `baksos_agendas` (');
  lines.push('  `id` VARCHAR(64) NOT NULL PRIMARY KEY,');
  lines.push('  `agenda_date` DATE NOT NULL,');
  lines.push('  `title` VARCHAR(200) NOT NULL,');
  lines.push('  `description` TEXT DEFAULT NULL,');
  lines.push('  `fine_amount` BIGINT NOT NULL DEFAULT 10000');
  lines.push(') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
  lines.push('');

  if (payload.baksosAgendas && payload.baksosAgendas.length > 0) {
    lines.push(
      'INSERT INTO `baksos_agendas` (`id`, `agenda_date`, `title`, `description`, `fine_amount`) VALUES'
    );
    const agendaRows = payload.baksosAgendas.map(
      (b) =>
        `  (${escapeSql(b.id)}, ${escapeSql(b.date)}, ${escapeSql(b.title)}, ${escapeSql(
          b.description || ''
        )}, ${Number(b.fineAmount || 10000)})`
    );
    lines.push(agendaRows.join(',\n') + ';');
  }
  lines.push('');

  // 6. Table: baksos_attendance
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('-- 6. Struktur Tabel `baksos_attendance` (Presensi & Status Denda Baksos Warga)');
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('DROP TABLE IF EXISTS `baksos_attendance`;');
  lines.push('CREATE TABLE `baksos_attendance` (');
  lines.push('  `agenda_id` VARCHAR(64) NOT NULL,');
  lines.push('  `resident_id` VARCHAR(64) NOT NULL,');
  lines.push('  `attendance_status` VARCHAR(32) NOT NULL DEFAULT \'Hadir\',');
  lines.push('  `fine_paid` TINYINT(1) NOT NULL DEFAULT 0,');
  lines.push('  PRIMARY KEY (`agenda_id`, `resident_id`)');
  lines.push(') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
  lines.push('');

  const attendanceRows: string[] = [];
  (payload.baksosAgendas || []).forEach((b) => {
    Object.entries(b.attendance || {}).forEach(([residentId, status]) => {
      const isFinePaid = Boolean(b.finesPaid?.[residentId]);
      attendanceRows.push(
        `  (${escapeSql(b.id)}, ${escapeSql(residentId)}, ${escapeSql(
          status
        )}, ${escapeSql(isFinePaid)})`
      );
    });
  });

  if (attendanceRows.length > 0) {
    lines.push(
      'INSERT INTO `baksos_attendance` (`agenda_id`, `resident_id`, `attendance_status`, `fine_paid`) VALUES'
    );
    lines.push(attendanceRows.join(',\n') + ';');
  }
  lines.push('');

  // 7. Table: committees
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('-- 7. Struktur Tabel `committees` (Kontak Pelayanan Publik & Pengurus)');
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('DROP TABLE IF EXISTS `committees`;');
  lines.push('CREATE TABLE `committees` (');
  lines.push('  `id` VARCHAR(64) NOT NULL PRIMARY KEY,');
  lines.push('  `full_name` VARCHAR(150) NOT NULL,');
  lines.push('  `role_title` VARCHAR(120) NOT NULL,');
  lines.push('  `phone_number` VARCHAR(40) NOT NULL');
  lines.push(') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
  lines.push('');

  if (payload.committees && payload.committees.length > 0) {
    lines.push('INSERT INTO `committees` (`id`, `full_name`, `role_title`, `phone_number`) VALUES');
    const committeeRows = payload.committees.map(
      (c) =>
        `  (${escapeSql(c.id)}, ${escapeSql(c.name)}, ${escapeSql(c.role)}, ${escapeSql(
          c.phone
        )})`
    );
    lines.push(committeeRows.join(',\n') + ';');
  }
  lines.push('');

  // 8. Table: announcements
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('-- 8. Struktur Tabel `announcements` (Papan Pengumuman & Informasi Warga)');
  lines.push('-- ----------------------------------------------------------------------------');
  lines.push('DROP TABLE IF EXISTS `announcements`;');
  lines.push('CREATE TABLE `announcements` (');
  lines.push('  `id` VARCHAR(64) NOT NULL PRIMARY KEY,');
  lines.push('  `title` VARCHAR(255) NOT NULL,');
  lines.push('  `publish_date` DATE NOT NULL,');
  lines.push('  `priority` ENUM(\'normal\', \'penting\', \'darurat\') NOT NULL DEFAULT \'normal\',');
  lines.push('  `content` TEXT NOT NULL');
  lines.push(') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
  lines.push('');

  if (payload.announcements && payload.announcements.length > 0) {
    lines.push('INSERT INTO `announcements` (`id`, `title`, `publish_date`, `priority`, `content`) VALUES');
    const annRows = payload.announcements.map(
      (a) =>
        `  (${escapeSql(a.id)}, ${escapeSql(a.title)}, ${escapeSql(a.date)}, ${escapeSql(
          a.priority
        )}, ${escapeSql(a.content)})`
    );
    lines.push(annRows.join(',\n') + ';');
  }

  lines.push('');
  lines.push('SET FOREIGN_KEY_CHECKS = 1;');
  lines.push('-- END OF MYSQL DUMP');

  return lines.join('\n');
}

/**
 * Trigger download file .sql langsung di browser untuk Admin
 */
export function downloadMySQLDumpFile(payload: MySQLDatabasePayload) {
  const sqlContent = generateMySQLDump(payload);
  const blob = new Blob([sqlContent], { type: 'application/sql;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  const datePart = new Date().toISOString().slice(0, 10);
  link.href = url;
  link.download = `database_mysql_warga_gang_mandor_${datePart}.sql`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
