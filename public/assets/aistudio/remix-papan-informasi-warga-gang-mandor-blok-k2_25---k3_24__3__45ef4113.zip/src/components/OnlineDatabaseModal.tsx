import React, { useRef, useState } from 'react';
import {
  Check,
  CheckCircle2,
  CloudUpload,
  Code2,
  Copy,
  Database,
  Download,
  FileJson,
  Globe,
  RefreshCw,
  Table2,
  Upload,
  Wifi,
  WifiOff,
  X,
} from 'lucide-react';
import { PortalDatabasePayload } from '../types';
import {
  downloadMySQLDumpFile,
  generateMySQLDump,
  getMySQLTablesSummary,
} from '../utils/mysqlDatabaseGenerator';

interface OnlineDatabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPayload: PortalDatabasePayload;
  onRestorePayload: (payload: PortalDatabasePayload) => void;
  lastOnlineSync: string | null;
  onlineRevision: number;
  isOnlineSyncing: boolean;
  isOnlineConnected: boolean;
  isAutoSyncEnabled: boolean;
  onToggleAutoSync: (enabled: boolean) => void;
  onSyncOnlineNow: (mode: 'pull' | 'push') => Promise<boolean>;
}

export const OnlineDatabaseModal: React.FC<OnlineDatabaseModalProps> = ({
  isOpen,
  onClose,
  currentPayload,
  onRestorePayload,
  lastOnlineSync,
  onlineRevision,
  isOnlineSyncing,
  isOnlineConnected,
  isAutoSyncEnabled,
  onToggleAutoSync,
  onSyncOnlineNow,
}) => {
  const [activeModalTab, setActiveModalTab] = useState<'online' | 'mysql'>('online');
  const [showSqlPreview, setShowSqlPreview] = useState<boolean>(false);
  const [copiedSql, setCopiedSql] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const mysqlTables = getMySQLTablesSummary(currentPayload);
  const totalMySQLRows = mysqlTables.reduce((sum, t) => sum + t.rowCount, 0);

  const handleCopySQL = async () => {
    try {
      const sqlText = generateMySQLDump(currentPayload);
      await navigator.clipboard.writeText(sqlText);
      setCopiedSql(true);
      setTimeout(() => setCopiedSql(false), 2500);
    } catch {}
  };

  const handlePullLatest = async () => {
    setStatusMessage(null);
    const ok = await onSyncOnlineNow('pull');
    if (ok) {
      setStatusMessage({
        type: 'success',
        text: 'Data terbaru dari server online berhasil disinkronkan ke perangkat ini!',
      });
    } else {
      setStatusMessage({
        type: 'error',
        text: 'Gagal mengambil data terbaru dari server online. Periksa koneksi internet Anda.',
      });
    }
  };

  const handlePushNow = async () => {
    setStatusMessage(null);
    const ok = await onSyncOnlineNow('push');
    if (ok) {
      setStatusMessage({
        type: 'success',
        text: 'Seluruh perubahan data berhasil disimpan & disiarkan otomatis ke semua perangkat online!',
      });
    } else {
      setStatusMessage({
        type: 'error',
        text: 'Gagal menyimpan data ke server online.',
      });
    }
  };

  const handleDownloadJsonBackup = () => {
    const dataStr = JSON.stringify(currentPayload, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const dateStamp = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `backup_online_warga_gang_mandor_${dateStamp}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportJsonFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(String(event.target?.result || '')) as PortalDatabasePayload;
        if (!parsed || !Array.isArray(parsed.residents)) {
          setStatusMessage({
            type: 'error',
            text: 'Format file JSON tidak valid.',
          });
          return;
        }
        onRestorePayload(parsed);
        setStatusMessage({
          type: 'success',
          text: 'Cadangan data berhasil dipulihkan dan otomatis disinkronkan ke server online!',
        });
      } catch {
        setStatusMessage({
          type: 'error',
          text: 'Gagal membaca file cadangan JSON.',
        });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-gradient-to-br from-emerald-50 via-cyan-50 to-indigo-50 rounded-2xl shadow-2xl border border-emerald-200 w-full max-w-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/15 rounded-xl">
              <Globe className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h2 className="font-bold text-base">
                Server Online Real-Time & Database MySQL Otomatis
              </h2>
              <p className="text-xs text-emerald-100">
                Website aktif secara online dan menyinkronkan data terbaru secara otomatis di semua perangkat
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Switcher Tabs */}
        <div className="bg-gradient-to-r from-emerald-100/80 via-teal-100/70 to-indigo-100/80 px-5 pt-3 pb-2 border-b border-emerald-200 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveModalTab('online')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeModalTab === 'online'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-xs'
                : 'text-slate-700 hover:bg-emerald-50/80'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>1. Sinkronisasi Server Online Otomatis</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveModalTab('mysql')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeModalTab === 'mysql'
                ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white shadow-xs'
                : 'text-slate-700 hover:bg-indigo-50/80'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>2. Database MySQL (8 Tabel Inputan Website)</span>
          </button>
        </div>

        <div className="p-6 space-y-5 max-h-[78vh] overflow-y-auto">
          {/* Online Server Status Banner */}
          <div
            className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs ${
              isOnlineConnected
                ? 'bg-gradient-to-r from-emerald-100/90 via-teal-50 to-cyan-100/80 border-emerald-300'
                : 'bg-amber-100/90 border-amber-300'
            }`}
          >
            <div className="flex items-center gap-2.5">
              {isOnlineConnected ? (
                <div className="relative flex items-center justify-center">
                  <span className="animate-ping absolute inline-flex h-3 w-3 rounded-full bg-emerald-400 opacity-75"></span>
                  <Wifi className="relative w-4 h-4 text-emerald-700 shrink-0" />
                </div>
              ) : (
                <WifiOff className="w-4 h-4 text-amber-700 shrink-0" />
              )}
              <div>
                <span className="font-bold text-emerald-950 block">
                  {isOnlineConnected
                    ? `Website Online & Sinkron Otomatis Aktif (${totalMySQLRows} Record · Revisi #${onlineRevision || 1})`
                    : 'Menghubungkan ulang ke Server Online...'}
                </span>
                <span className="text-emerald-800 text-[11px]">
                  Setiap perubahan data Pengumuman, Kas, Iuran KK, Baksos, Warga & Tunggakan langsung tersimpan di server dan diperbarui otomatis ke seluruh pengguna.
                </span>
              </div>
            </div>
            {lastOnlineSync && (
              <span className="font-mono text-[10px] font-semibold px-2.5 py-1 rounded-lg bg-emerald-200/70 text-emerald-900 shrink-0 tabular-nums">
                Update: {new Date(lastOnlineSync).toLocaleTimeString('id-ID')}
              </span>
            )}
          </div>

          {statusMessage && (
            <div
              className={`p-3 rounded-xl border text-xs font-medium flex items-center justify-between gap-2 ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-100/90 border-emerald-300 text-emerald-900'
                  : statusMessage.type === 'error'
                  ? 'bg-rose-100/90 border-rose-300 text-rose-900'
                  : 'bg-sky-100/90 border-sky-300 text-sky-900'
              }`}
            >
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{statusMessage.text}</span>
              </div>
              <button
                type="button"
                onClick={() => setStatusMessage(null)}
                className="text-xs opacity-70 hover:opacity-100 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {activeModalTab === 'online' ? (
            <div className="space-y-4">
              {/* Auto-Sync Control Card */}
              <div className="p-4 rounded-2xl border border-teal-200 bg-gradient-to-br from-teal-50/90 via-emerald-50/70 to-cyan-50/90 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-teal-800 block">
                      Sinkronisasi Real-Time Lintas Perangkat (Tanpa Google Drive)
                    </span>
                    <h3 className="font-bold text-sm text-slate-900 mt-0.5">
                      Sinkronkan Otomatis Data Terbaru
                    </h3>
                    <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                      Saat aktif, setiap perubahan data otomatis dikirim ke server utama dan langsung tampil di HP/laptop warga lain secara real-time tanpa perlu muat ulang halaman.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => onToggleAutoSync(!isAutoSyncEnabled)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer shrink-0 flex items-center gap-2 ${
                      isAutoSyncEnabled
                        ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs'
                        : 'bg-amber-100 text-amber-900 border-amber-300'
                    }`}
                  >
                    <span
                      className={`w-2 h-2 rounded-full ${
                        isAutoSyncEnabled ? 'bg-amber-300 animate-pulse' : 'bg-amber-600'
                      }`}
                    />
                    <span>{isAutoSyncEnabled ? 'Auto-Sync: AKTIF' : 'Auto-Sync: NONAKTIF'}</span>
                  </button>
                </div>

                {/* Manual Sync Action Buttons */}
                <div className="pt-3 border-t border-teal-200/70 flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    onClick={handlePullLatest}
                    disabled={isOnlineSyncing}
                    className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer disabled:opacity-60"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isOnlineSyncing ? 'animate-spin' : ''}`} />
                    <span>Muat Data Terbaru dari Server</span>
                  </button>

                  <button
                    type="button"
                    onClick={handlePushNow}
                    disabled={isOnlineSyncing}
                    className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer disabled:opacity-60"
                  >
                    <CloudUpload className="w-3.5 h-3.5 text-amber-300" />
                    <span>Simpan & Siarkan ke Semua Perangkat</span>
                  </button>
                </div>
              </div>

              {/* Backup & Restore File JSON */}
              <div className="p-4 rounded-2xl border border-indigo-200 bg-gradient-to-br from-indigo-50/80 via-sky-50/70 to-emerald-50/60 space-y-3">
                <div className="flex items-center gap-2">
                  <FileJson className="w-4 h-4 text-indigo-600" />
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Cadangan File Database Online (.JSON)
                  </h4>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Unduh salinan lengkap seluruh database portal atau pulihkan data dari file cadangan untuk disinkronkan langsung ke server online.
                </p>
                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    onClick={handleDownloadJsonBackup}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-2xs transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-amber-300" />
                    <span>Download Backup (.json)</span>
                  </button>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".json,application/json"
                    onChange={handleImportJsonFile}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-100 hover:bg-amber-200 text-amber-950 border border-amber-300 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5 text-amber-700" />
                    <span>Pulihkan dari File (.json)</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* MySQL Action Bar */}
              <div className="p-4 rounded-2xl border border-indigo-200 bg-gradient-to-br from-indigo-50/90 via-sky-50/80 to-emerald-50/70 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-700 block">
                      MySQL Relational Database Engine (InnoDB / utf8mb4)
                    </span>
                    <div className="font-mono font-bold text-sm text-slate-900 mt-0.5">
                      Database: `db_warga_gang_mandor` (8 Tabel Relasional)
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => downloadMySQLDumpFile(currentPayload)}
                      className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5 text-amber-300" />
                      <span>Download Database MySQL (.sql)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowSqlPreview((prev) => !prev)}
                      className="flex items-center gap-1.5 px-3 py-2 bg-indigo-100 hover:bg-indigo-200 text-indigo-900 border border-indigo-300 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                    >
                      <Code2 className="w-3.5 h-3.5 text-indigo-700" />
                      <span>{showSqlPreview ? 'Sembunyikan Query SQL' : 'Lihat Query SQL'}</span>
                    </button>
                  </div>
                </div>

                {showSqlPreview && (
                  <div className="space-y-2 pt-2 border-t border-indigo-200/60">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-mono font-semibold text-slate-700">
                        Preview Live MySQL Dump (`database_warga_gang_mandor.sql`)
                      </span>
                      <button
                        type="button"
                        onClick={handleCopySQL}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-600 text-white font-semibold text-[11px] cursor-pointer"
                      >
                        {copiedSql ? (
                          <>
                            <Check className="w-3 h-3" />
                            <span>Tersalin!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Salin Semua SQL</span>
                          </>
                        )}
                      </button>
                    </div>
                    <pre className="p-3 rounded-xl bg-slate-900 text-emerald-300 font-mono text-[11px] max-h-56 overflow-auto leading-relaxed">
                      {generateMySQLDump(currentPayload)}
                    </pre>
                  </div>
                )}
              </div>

              {/* 8 MySQL Tables Breakdown */}
              <div className="space-y-2.5">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                  <Table2 className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Daftar 8 Tabel MySQL untuk Seluruh Inputan Website</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {mysqlTables.map((tbl) => (
                    <div
                      key={tbl.tableName}
                      className="p-3 rounded-xl border border-indigo-200/80 bg-gradient-to-br from-indigo-50/70 via-cyan-50/50 to-emerald-50/60 flex flex-col justify-between space-y-2"
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono font-bold text-xs text-indigo-800">
                            `{tbl.tableName}`
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-mono text-[10px] font-bold tabular-nums">
                            {tbl.rowCount} Baris
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 mt-1 leading-snug">
                          {tbl.description}
                        </p>
                      </div>
                      <div className="pt-1.5 border-t border-indigo-200/60 text-[10px] font-mono text-slate-500 truncate">
                        PK: <strong>{tbl.primaryKey}</strong> · Kolom: {tbl.columns.join(', ')}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
